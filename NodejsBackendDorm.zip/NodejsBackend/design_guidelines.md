# Design Guidelines - Dorm Management Website Backend Integration

## Context
You have provided a **complete frontend implementation** in React/TypeScript with established UI components, styling, and user flows. Since your request focuses on backend development, minimal design guidelines are needed.

## Existing Frontend Architecture
Your application already implements:
- **Design System**: Radix UI components with Tailwind CSS
- **Role-Based Interfaces**: Tenant, Admin, and Help Desk dashboards
- **Authentication Flow**: Login/logout with user state management
- **Component Structure**: Modular page components (HomePage, LoginPage, TenantPage, AdminPage, HelpDeskPage)

## Design Consistency for Additional Features

### Typography & Spacing
- **Continue using**: Tailwind spacing units (2, 4, 8 as primary scale)
- **Text hierarchy**: Maintain existing patterns from Radix UI components
- **Consistent padding**: Apply py-4 to py-8 for sections, p-4 to p-6 for cards

### Component Patterns
- **Forms**: Use existing Radix UI form components (Label, Input, Select) with consistent validation states
- **Data Tables**: Implement responsive tables with consistent row/cell padding
- **Cards**: Maintain card-based layouts for dashboard widgets with rounded corners and subtle shadows
- **Buttons**: Primary actions use filled buttons, secondary actions use outline variants

### Dashboard Layouts
- **Admin Dashboard**: Grid-based layout for statistics, 2-3 columns for management sections
- **Tenant Dashboard**: Single-column mobile-first with key info prominently displayed
- **Help Desk**: Ticket list with status badges, detail view with timeline

### Data Visualization
- Use **Recharts** (already in dependencies) for statistics and analytics
- Color-code status indicators: Green (resolved), Yellow (pending), Red (urgent)

### Images
Not required for this administrative application - focus on functional, data-driven interfaces.

**Note**: Your frontend is production-ready. These guidelines ensure consistency when adding new backend-driven features.