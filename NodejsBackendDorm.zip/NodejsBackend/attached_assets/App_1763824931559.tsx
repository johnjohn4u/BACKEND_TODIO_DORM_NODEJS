import { useState } from 'react';
import { HomePage } from './components/HomePage';
import { LoginPage } from './components/LoginPage';
import { TenantPage } from './components/TenantPage';
import { AdminPage } from './components/AdminPage';
import { HelpDeskPage } from './components/HelpDeskPage';

export type UserRole = 'tenant' | 'admin' | 'helpdesk' | null;

export interface UserData {
  username: string;
  role: UserRole;
  fullName: string;
  room?: string;
  building?: string;
}

type AppState = 'home' | 'login' | 'dashboard';

export default function App() {
  const [appState, setAppState] = useState<AppState>('home');
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);

  const handleNavigateToLogin = () => {
    setAppState('login');
  };

  const handleLogin = (userData: UserData) => {
    setCurrentUser(userData);
    setAppState('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setAppState('home');
  };

  const handleBackToHome = () => {
    setAppState('home');
  };

  if (appState === 'home') {
    return <HomePage onNavigateToLogin={handleNavigateToLogin} />;
  }

  if (appState === 'login') {
    return <LoginPage onLogin={handleLogin} onBackToHome={handleBackToHome} />;
  }

  if (appState === 'dashboard' && currentUser) {
    if (currentUser.role === 'tenant') {
      return <TenantPage user={currentUser} onLogout={handleLogout} />;
    }
    if (currentUser.role === 'admin') {
      return <AdminPage user={currentUser} onLogout={handleLogout} />;
    }
    if (currentUser.role === 'helpdesk') {
      return <HelpDeskPage user={currentUser} onLogout={handleLogout} />;
    }
  }

  return <HomePage onNavigateToLogin={handleNavigateToLogin} />;
}