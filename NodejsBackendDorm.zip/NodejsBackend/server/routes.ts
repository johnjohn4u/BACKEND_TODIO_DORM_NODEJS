import type { Express } from "express";
import { createServer, type Server } from "http";
import { DrizzleStorage } from "./storage-db";
import bcrypt from "bcrypt";
import { requireAuth, requireRole, getCurrentUser, generateToken, type AuthRequest } from "./middleware";
import {
  loginSchema,
  insertUserSchema,
  insertBuildingSchema,
  insertRoomSchema,
  insertTicketSchema,
  updateTicketSchema,
  insertAnnouncementSchema,
  insertTicketCommentSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const storage = new DrizzleStorage();

  // Seed data if needed
  try {
    const existingUsers = await storage.getAllUsers();
    if (existingUsers.length === 0) {
      await storage.seedData();
    }
  } catch (error) {
    console.error("Failed to seed data:", error);
  }

  // ============================================
  // Authentication Routes
  // ============================================

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const userWithRoomInfo = await storage.getUserWithRoomInfo(user.id);
      const token = generateToken(user.id, user.role);
      return res.json({ user: userWithRoomInfo, token });
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Login failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);

      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }

      const hashedPassword = await bcrypt.hash(userData.password, 10);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      const userWithRoomInfo = await storage.getUserWithRoomInfo(user.id);
      const token = generateToken(user.id, user.role);
      return res.status(201).json({ user: userWithRoomInfo, token });
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  // ============================================
  // User Management Routes
  // ============================================

  app.get("/api/users", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      return res.json(users);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUserWithRoomInfo(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      return res.json(user);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/users", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);

      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }

      const hashedPassword = await bcrypt.hash(userData.password, 10);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      const userWithoutPassword = await storage.getUserWithoutPassword(user.id);
      return res.status(201).json(userWithoutPassword);
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const updates = req.body;
      
      if (updates.password) {
        updates.password = await bcrypt.hash(updates.password, 10);
      }

      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const userWithoutPassword = await storage.getUserWithoutPassword(user.id);
      return res.json(userWithoutPassword);
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  // ============================================
  // Building Management Routes
  // ============================================

  app.get("/api/buildings", requireAuth, async (req, res) => {
    try {
      const buildings = await storage.getAllBuildings();
      return res.json(buildings);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/buildings/:id", async (req, res) => {
    try {
      const building = await storage.getBuilding(req.params.id);
      if (!building) {
        return res.status(404).json({ message: "Building not found" });
      }
      return res.json(building);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/buildings", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const buildingData = insertBuildingSchema.parse(req.body);
      const building = await storage.createBuilding(buildingData);
      return res.status(201).json(building);
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Failed to create building" });
    }
  });

  app.patch("/api/buildings/:id", async (req, res) => {
    try {
      const building = await storage.updateBuilding(req.params.id, req.body);
      if (!building) {
        return res.status(404).json({ message: "Building not found" });
      }
      return res.json(building);
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/buildings/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteBuilding(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Building not found" });
      }
      return res.status(204).send();
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  // ============================================
  // Room Management Routes
  // ============================================

  app.get("/api/rooms", requireAuth, async (req, res) => {
    try {
      const { buildingId } = req.query;
      let rooms;
      
      if (buildingId && typeof buildingId === 'string') {
        rooms = await storage.getRoomsByBuilding(buildingId);
      } else {
        rooms = await storage.getAllRooms();
      }
      
      return res.json(rooms);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/rooms/:id", async (req, res) => {
    try {
      const room = await storage.getRoom(req.params.id);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      return res.json(room);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/rooms", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const roomData = insertRoomSchema.parse(req.body);
      const room = await storage.createRoom(roomData);
      return res.status(201).json(room);
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Failed to create room" });
    }
  });

  app.patch("/api/rooms/:id", async (req, res) => {
    try {
      const room = await storage.updateRoom(req.params.id, req.body);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      return res.json(room);
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/rooms/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteRoom(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Room not found" });
      }
      return res.status(204).send();
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  // ============================================
  // Ticket Management Routes
  // ============================================

  app.get("/api/tickets", requireAuth, requireRole('admin', 'helpdesk'), async (req, res) => {
    try {
      const tickets = await storage.getAllTickets();
      return res.json(tickets);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tickets/my-tickets", requireAuth, async (req, res) => {
    try {
      const { userId } = req.query;
      if (!userId || typeof userId !== 'string') {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const tickets = await storage.getTicketsByUser(userId);
      return res.json(tickets);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tickets/:id", async (req, res) => {
    try {
      const ticket = await storage.getTicketWithDetails(req.params.id);
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      return res.json(ticket);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tickets", requireAuth, async (req, res) => {
    try {
      const ticketData = insertTicketSchema.parse(req.body);
      
      // Get the current user from localStorage (in a real app, this would come from auth middleware)
      // For now, we'll use the createdById from the request
      const ticket = await storage.createTicket(ticketData);
      const ticketWithDetails = await storage.getTicketWithDetails(ticket.id);
      
      return res.status(201).json(ticketWithDetails);
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Failed to create ticket" });
    }
  });

  app.patch("/api/tickets/:id", requireAuth, requireRole('admin', 'helpdesk'), async (req, res) => {
    try {
      const updates = updateTicketSchema.parse(req.body);
      const ticket = await storage.updateTicket(req.params.id, updates);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      const ticketWithDetails = await storage.getTicketWithDetails(ticket.id);
      return res.json(ticketWithDetails);
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/tickets/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTicket(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      return res.status(204).send();
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  // ============================================
  // Ticket Comments Routes
  // ============================================

  app.get("/api/tickets/:ticketId/comments", async (req, res) => {
    try {
      const comments = await storage.getCommentsByTicket(req.params.ticketId);
      return res.json(comments);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tickets/:ticketId/comments", requireAuth, async (req, res) => {
    try {
      const commentData = insertTicketCommentSchema.parse({
        ...req.body,
        ticketId: req.params.ticketId,
      });
      
      const comment = await storage.createTicketComment(commentData);
      return res.status(201).json(comment);
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Failed to create comment" });
    }
  });

  // ============================================
  // Announcement Routes
  // ============================================

  app.get("/api/announcements", requireAuth, async (req, res) => {
    try {
      const { role } = req.query;
      let announcements;
      
      if (role && typeof role === 'string') {
        announcements = await storage.getAnnouncementsForUser(role);
      } else {
        announcements = await storage.getAllAnnouncements();
      }
      
      return res.json(announcements);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/announcements/:id", async (req, res) => {
    try {
      const announcement = await storage.getAnnouncement(req.params.id);
      if (!announcement) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      return res.json(announcement);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/announcements", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const announcementData = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(announcementData);
      return res.status(201).json(announcement);
    } catch (error: any) {
      return res.status(400).json({ message: error.message || "Failed to create announcement" });
    }
  });

  app.delete("/api/announcements/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteAnnouncement(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      return res.status(204).send();
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  // ============================================
  // Statistics Routes
  // ============================================

  app.get("/api/admin/stats", requireAuth, requireRole('admin'), async (req, res) => {
    try {
      const stats = await storage.getStats();
      return res.json(stats);
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
