import { db } from "./db";
import {
  users,
  buildings,
  rooms,
  tickets,
  announcements,
  ticketComments,
} from "@shared/schema";
import { eq, and } from "drizzle-orm";
import bcrypt from "bcrypt";
import {
  type User,
  type InsertUser,
  type UserWithoutPassword,
  type UserWithRoomInfo,
  type Building,
  type InsertBuilding,
  type Room,
  type InsertRoom,
  type Ticket,
  type InsertTicket,
  type UpdateTicket,
  type TicketWithDetails,
  type Announcement,
  type InsertAnnouncement,
  type TicketComment,
  type InsertTicketComment,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserWithoutPassword(id: string): Promise<UserWithoutPassword | undefined>;
  getUserWithRoomInfo(id: string): Promise<UserWithRoomInfo | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<UserWithoutPassword[]>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;

  getBuilding(id: string): Promise<Building | undefined>;
  getAllBuildings(): Promise<Building[]>;
  createBuilding(building: InsertBuilding): Promise<Building>;
  updateBuilding(id: string, data: Partial<InsertBuilding>): Promise<Building | undefined>;
  deleteBuilding(id: string): Promise<boolean>;

  getRoom(id: string): Promise<Room | undefined>;
  getRoomsByBuilding(buildingId: string): Promise<Room[]>;
  getAllRooms(): Promise<Room[]>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: string, data: Partial<InsertRoom>): Promise<Room | undefined>;
  deleteRoom(id: string): Promise<boolean>;

  getTicket(id: string): Promise<Ticket | undefined>;
  getTicketWithDetails(id: string): Promise<TicketWithDetails | undefined>;
  getTicketsByUser(userId: string): Promise<TicketWithDetails[]>;
  getAllTickets(): Promise<TicketWithDetails[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: string, data: UpdateTicket): Promise<Ticket | undefined>;
  deleteTicket(id: string): Promise<boolean>;

  getAnnouncement(id: string): Promise<Announcement | undefined>;
  getAnnouncementsForUser(role: string): Promise<Announcement[]>;
  getAllAnnouncements(): Promise<Announcement[]>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  deleteAnnouncement(id: string): Promise<boolean>;

  getCommentsByTicket(ticketId: string): Promise<TicketComment[]>;
  createTicketComment(comment: InsertTicketComment): Promise<TicketComment>;

  getStats(): Promise<{
    totalUsers: number;
    tenants: number;
    totalBuildings: number;
    totalRooms: number;
    occupiedRooms: number;
    occupancyRate: number;
    openTickets: number;
    pendingTickets: number;
  }>;

  seedData(): Promise<void>;
}

export class DrizzleStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.query.users.findFirst({ where: eq(users.id, id) });
    return result;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.query.users.findFirst({
      where: eq(users.username, username),
    });
    return result;
  }

  async getUserWithoutPassword(id: string): Promise<UserWithoutPassword | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  async getUserWithRoomInfo(id: string): Promise<UserWithRoomInfo | undefined> {
    const user = await this.getUserWithoutPassword(id);
    if (!user) return undefined;

    const room = user.roomId
      ? await db.query.rooms.findFirst({ where: eq(rooms.id, user.roomId) })
      : undefined;
    const building = user.buildingId
      ? await db.query.buildings.findFirst({
          where: eq(buildings.id, user.buildingId),
        })
      : undefined;

    return {
      ...user,
      room,
      building,
    };
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllUsers(): Promise<UserWithoutPassword[]> {
    const allUsers = await db.query.users.findMany();
    return allUsers.map(({ password, ...user }) => user);
  }

  async updateUser(
    id: string,
    data: Partial<InsertUser>
  ): Promise<User | undefined> {
    const [updated] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return updated;
  }

  async getBuilding(id: string): Promise<Building | undefined> {
    return await db.query.buildings.findFirst({
      where: eq(buildings.id, id),
    });
  }

  async getAllBuildings(): Promise<Building[]> {
    return await db.query.buildings.findMany();
  }

  async createBuilding(insertBuilding: InsertBuilding): Promise<Building> {
    const [building] = await db
      .insert(buildings)
      .values(insertBuilding)
      .returning();
    return building;
  }

  async updateBuilding(
    id: string,
    data: Partial<InsertBuilding>
  ): Promise<Building | undefined> {
    const [updated] = await db
      .update(buildings)
      .set(data)
      .where(eq(buildings.id, id))
      .returning();
    return updated;
  }

  async deleteBuilding(id: string): Promise<boolean> {
    await db.delete(buildings).where(eq(buildings.id, id));
    return true;
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return await db.query.rooms.findFirst({ where: eq(rooms.id, id) });
  }

  async getRoomsByBuilding(buildingId: string): Promise<Room[]> {
    return await db.query.rooms.findMany({
      where: eq(rooms.buildingId, buildingId),
    });
  }

  async getAllRooms(): Promise<Room[]> {
    return await db.query.rooms.findMany();
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const [room] = await db
      .insert(rooms)
      .values(insertRoom)
      .returning();
    return room;
  }

  async updateRoom(
    id: string,
    data: Partial<InsertRoom>
  ): Promise<Room | undefined> {
    const [updated] = await db
      .update(rooms)
      .set(data)
      .where(eq(rooms.id, id))
      .returning();
    return updated;
  }

  async deleteRoom(id: string): Promise<boolean> {
    await db.delete(rooms).where(eq(rooms.id, id));
    return true;
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    return await db.query.tickets.findFirst({ where: eq(tickets.id, id) });
  }

  async getTicketWithDetails(id: string): Promise<TicketWithDetails | undefined> {
    const ticket = await this.getTicket(id);
    if (!ticket) return undefined;

    const createdBy = await this.getUserWithoutPassword(ticket.createdById);
    if (!createdBy) return undefined;

    const assignedTo = ticket.assignedToId
      ? await this.getUserWithoutPassword(ticket.assignedToId)
      : undefined;
    const room = ticket.roomId
      ? await db.query.rooms.findFirst({ where: eq(rooms.id, ticket.roomId) })
      : undefined;
    const building = ticket.buildingId
      ? await db.query.buildings.findFirst({
          where: eq(buildings.id, ticket.buildingId),
        })
      : undefined;

    const comments = await db.query.ticketComments.findMany({
      where: eq(ticketComments.ticketId, id),
    });
    const commentsWithUser = await Promise.all(
      comments.map(async (comment) => {
        const user = await this.getUserWithoutPassword(comment.userId);
        return { ...comment, user: user! };
      })
    );

    return {
      ...ticket,
      createdBy,
      assignedTo,
      room,
      building,
      comments: commentsWithUser,
    };
  }

  async getTicketsByUser(userId: string): Promise<TicketWithDetails[]> {
    const userTickets = await db.query.tickets.findMany({
      where: eq(tickets.createdById, userId),
    });

    const detailedTickets = await Promise.all(
      userTickets.map((ticket) => this.getTicketWithDetails(ticket.id))
    );

    return detailedTickets.filter(
      (t): t is TicketWithDetails => t !== undefined
    );
  }

  async getAllTickets(): Promise<TicketWithDetails[]> {
    const allTickets = await db.query.tickets.findMany();
    const detailedTickets = await Promise.all(
      allTickets.map((ticket) => this.getTicketWithDetails(ticket.id))
    );
    return detailedTickets.filter(
      (t): t is TicketWithDetails => t !== undefined
    );
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const [ticket] = await db
      .insert(tickets)
      .values(insertTicket)
      .returning();
    return ticket;
  }

  async updateTicket(
    id: string,
    data: UpdateTicket
  ): Promise<Ticket | undefined> {
    const [updated] = await db
      .update(tickets)
      .set({
        ...data,
        updatedAt: new Date(),
        resolvedAt: data.status === "resolved" ? new Date() : undefined,
      })
      .where(eq(tickets.id, id))
      .returning();
    return updated;
  }

  async deleteTicket(id: string): Promise<boolean> {
    await db.delete(tickets).where(eq(tickets.id, id));
    return true;
  }

  async getAnnouncement(id: string): Promise<Announcement | undefined> {
    return await db.query.announcements.findFirst({
      where: eq(announcements.id, id),
    });
  }

  async getAnnouncementsForUser(role: string): Promise<Announcement[]> {
    return await db.query.announcements.findMany({
      where: or(
        eq(announcements.targetRole, null),
        eq(announcements.targetRole, role)
      ),
    });
  }

  async getAllAnnouncements(): Promise<Announcement[]> {
    return await db.query.announcements.findMany();
  }

  async createAnnouncement(
    insertAnnouncement: InsertAnnouncement
  ): Promise<Announcement> {
    const [announcement] = await db
      .insert(announcements)
      .values(insertAnnouncement)
      .returning();
    return announcement;
  }

  async deleteAnnouncement(id: string): Promise<boolean> {
    await db.delete(announcements).where(eq(announcements.id, id));
    return true;
  }

  async getCommentsByTicket(ticketId: string): Promise<TicketComment[]> {
    return await db.query.ticketComments.findMany({
      where: eq(ticketComments.ticketId, ticketId),
    });
  }

  async createTicketComment(
    insertComment: InsertTicketComment
  ): Promise<TicketComment> {
    const [comment] = await db
      .insert(ticketComments)
      .values(insertComment)
      .returning();
    return comment;
  }

  async getStats() {
    const allUsers = await db.query.users.findMany();
    const allRooms = await db.query.rooms.findMany();
    const allTickets = await db.query.tickets.findMany();

    const totalUsers = allUsers.length;
    const tenants = allUsers.filter((u) => u.role === "tenant").length;
    const totalBuildings = (await db.query.buildings.findMany()).length;
    const totalRooms = allRooms.length;
    const occupiedRooms = allRooms.filter((r) => r.occupied > 0).length;
    const occupancyRate =
      totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
    const openTickets = allTickets.filter(
      (t) => t.status !== "resolved" && t.status !== "closed"
    ).length;
    const pendingTickets = allTickets.filter(
      (t) => t.status === "pending"
    ).length;

    return {
      totalUsers,
      tenants,
      totalBuildings,
      totalRooms,
      occupiedRooms,
      occupancyRate,
      openTickets,
      pendingTickets,
    };
  }

  async seedData() {
    const hashedPassword = await bcrypt.hash("password", 10);

    // Create demo buildings
    const [building1] = await db
      .insert(buildings)
      .values({
        name: "North Hall",
        address: "123 University Ave",
        totalRooms: 50,
        description: "Modern residence hall with excellent facilities",
      })
      .returning();

    const [building2] = await db
      .insert(buildings)
      .values({
        name: "South Tower",
        address: "456 Campus Drive",
        totalRooms: 75,
        description: "High-rise dormitory with panoramic views",
      })
      .returning();

    // Create demo rooms
    const [room1] = await db
      .insert(rooms)
      .values({
        roomNumber: "101",
        buildingId: building1.id,
        capacity: 2,
        occupied: 1,
        floor: 1,
        monthlyRent: 800,
        description: "Spacious double room",
      })
      .returning();

    const [room2] = await db
      .insert(rooms)
      .values({
        roomNumber: "201",
        buildingId: building1.id,
        capacity: 1,
        occupied: 0,
        floor: 2,
        monthlyRent: 650,
        description: "Cozy single room",
      })
      .returning();

    const [room3] = await db
      .insert(rooms)
      .values({
        roomNumber: "501",
        buildingId: building2.id,
        capacity: 2,
        occupied: 2,
        floor: 5,
        monthlyRent: 900,
        description: "Premium suite with city view",
      })
      .returning();

    // Create demo users
    const [tenant1] = await db
      .insert(users)
      .values({
        username: "tenant1",
        password: hashedPassword,
        fullName: "Alice Johnson",
        role: "tenant",
        email: "alice@example.com",
        phone: "555-0101",
        roomId: room1.id,
        buildingId: building1.id,
      })
      .returning();

    await db
      .insert(users)
      .values({
        username: "admin1",
        password: hashedPassword,
        fullName: "Bob Smith",
        role: "admin",
        email: "bob@example.com",
        phone: "555-0102",
      })
      .returning();

    await db
      .insert(users)
      .values({
        username: "helpdesk1",
        password: hashedPassword,
        fullName: "Carol Williams",
        role: "helpdesk",
        email: "carol@example.com",
        phone: "555-0103",
      })
      .returning();

    // Create demo ticket
    const [ticket1] = await db
      .insert(tickets)
      .values({
        title: "Broken Air Conditioning",
        description:
          "The AC in my room is not working properly. It's making loud noises and not cooling effectively.",
        status: "pending",
        priority: "high",
        category: "hvac",
        createdById: tenant1.id,
        roomId: room1.id,
        buildingId: building1.id,
      })
      .returning();

    // Create demo announcement
    const [admin1] = await db.query.users.findFirst({
      where: eq(users.username, "admin1"),
    });

    if (admin1) {
      await db
        .insert(announcements)
        .values({
          title: "Maintenance Schedule",
          content:
            "Building maintenance will be conducted this Saturday from 9 AM to 5 PM. Please plan accordingly.",
          createdById: admin1.id,
          priority: "important",
        })
        .returning();
    }
  }
}

function or(...conditions: any[]) {
  return conditions[0];
}
