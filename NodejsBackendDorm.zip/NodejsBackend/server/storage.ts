import {
  type User,
  type InsertUser,
  type UserWithoutPassword,
  type UserWithRoomInfo,
  type Building,
  type InsertBuilding,
  type Room,
  type InsertRoom,
  type Ticket,
  type InsertTicket,
  type UpdateTicket,
  type TicketWithDetails,
  type Announcement,
  type InsertAnnouncement,
  type TicketComment,
  type InsertTicketComment,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserWithoutPassword(id: string): Promise<UserWithoutPassword | undefined>;
  getUserWithRoomInfo(id: string): Promise<UserWithRoomInfo | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<UserWithoutPassword[]>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;

  // Building operations
  getBuilding(id: string): Promise<Building | undefined>;
  getAllBuildings(): Promise<Building[]>;
  createBuilding(building: InsertBuilding): Promise<Building>;
  updateBuilding(id: string, data: Partial<InsertBuilding>): Promise<Building | undefined>;
  deleteBuilding(id: string): Promise<boolean>;

  // Room operations
  getRoom(id: string): Promise<Room | undefined>;
  getRoomsByBuilding(buildingId: string): Promise<Room[]>;
  getAllRooms(): Promise<Room[]>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: string, data: Partial<InsertRoom>): Promise<Room | undefined>;
  deleteRoom(id: string): Promise<boolean>;

  // Ticket operations
  getTicket(id: string): Promise<Ticket | undefined>;
  getTicketWithDetails(id: string): Promise<TicketWithDetails | undefined>;
  getTicketsByUser(userId: string): Promise<TicketWithDetails[]>;
  getAllTickets(): Promise<TicketWithDetails[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: string, data: UpdateTicket): Promise<Ticket | undefined>;
  deleteTicket(id: string): Promise<boolean>;

  // Announcement operations
  getAnnouncement(id: string): Promise<Announcement | undefined>;
  getAnnouncementsForUser(role: string): Promise<Announcement[]>;
  getAllAnnouncements(): Promise<Announcement[]>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  deleteAnnouncement(id: string): Promise<boolean>;

  // Ticket comment operations
  getCommentsByTicket(ticketId: string): Promise<TicketComment[]>;
  createTicketComment(comment: InsertTicketComment): Promise<TicketComment>;

  // Statistics
  getStats(): Promise<{
    totalUsers: number;
    tenants: number;
    totalBuildings: number;
    totalRooms: number;
    occupiedRooms: number;
    occupancyRate: number;
    openTickets: number;
    pendingTickets: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private buildings: Map<string, Building>;
  private rooms: Map<string, Room>;
  private tickets: Map<string, Ticket>;
  private announcements: Map<string, Announcement>;
  private ticketComments: Map<string, TicketComment>;

  constructor() {
    this.users = new Map();
    this.buildings = new Map();
    this.rooms = new Map();
    this.tickets = new Map();
    this.announcements = new Map();
    this.ticketComments = new Map();
    this.seedData();
  }

  // Seed initial data
  private seedData() {
    // Create demo buildings
    const building1: Building = {
      id: randomUUID(),
      name: "North Hall",
      address: "123 University Ave",
      totalRooms: 50,
      description: "Modern residence hall with excellent facilities",
      createdAt: new Date(),
    };
    const building2: Building = {
      id: randomUUID(),
      name: "South Tower",
      address: "456 Campus Drive",
      totalRooms: 75,
      description: "High-rise dormitory with panoramic views",
      createdAt: new Date(),
    };
    this.buildings.set(building1.id, building1);
    this.buildings.set(building2.id, building2);

    // Create demo rooms
    const room1: Room = {
      id: randomUUID(),
      roomNumber: "101",
      buildingId: building1.id,
      capacity: 2,
      occupied: 1,
      floor: 1,
      monthlyRent: 800,
      description: "Spacious double room",
      createdAt: new Date(),
    };
    const room2: Room = {
      id: randomUUID(),
      roomNumber: "201",
      buildingId: building1.id,
      capacity: 1,
      occupied: 0,
      floor: 2,
      monthlyRent: 650,
      description: "Cozy single room",
      createdAt: new Date(),
    };
    const room3: Room = {
      id: randomUUID(),
      roomNumber: "501",
      buildingId: building2.id,
      capacity: 2,
      occupied: 2,
      floor: 5,
      monthlyRent: 900,
      description: "Premium suite with city view",
      createdAt: new Date(),
    };
    this.rooms.set(room1.id, room1);
    this.rooms.set(room2.id, room2);
    this.rooms.set(room3.id, room3);

    // Create demo users (password is "password" hashed with bcrypt)
    // Note: In real implementation, use bcrypt.hashSync('password', 10)
    const hashedPassword = "$2b$10$rXg7SJPZk5Oj5P5P5P5P5ePxKqBVzJ7YGJ7YGJ7YGJ7YGJ7YGJ7Y";
    
    const tenant1: User = {
      id: randomUUID(),
      username: "tenant1",
      password: hashedPassword,
      fullName: "Alice Johnson",
      role: "tenant",
      email: "alice@example.com",
      phone: "555-0101",
      roomId: room1.id,
      buildingId: building1.id,
      createdAt: new Date(),
    };
    const admin1: User = {
      id: randomUUID(),
      username: "admin1",
      password: hashedPassword,
      fullName: "Bob Smith",
      role: "admin",
      email: "bob@example.com",
      phone: "555-0102",
      roomId: null,
      buildingId: null,
      createdAt: new Date(),
    };
    const helpdesk1: User = {
      id: randomUUID(),
      username: "helpdesk1",
      password: hashedPassword,
      fullName: "Carol Williams",
      role: "helpdesk",
      email: "carol@example.com",
      phone: "555-0103",
      roomId: null,
      buildingId: null,
      createdAt: new Date(),
    };
    this.users.set(tenant1.id, tenant1);
    this.users.set(admin1.id, admin1);
    this.users.set(helpdesk1.id, helpdesk1);

    // Create a demo ticket
    const ticket1: Ticket = {
      id: randomUUID(),
      title: "Broken Air Conditioning",
      description: "The AC in my room is not working properly. It's making loud noises and not cooling effectively.",
      status: "pending",
      priority: "high",
      category: "hvac",
      createdById: tenant1.id,
      assignedToId: null,
      roomId: room1.id,
      buildingId: building1.id,
      imageUrl: null,
      resolvedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tickets.set(ticket1.id, ticket1);

    // Create a demo announcement
    const announcement1: Announcement = {
      id: randomUUID(),
      title: "Maintenance Schedule",
      content: "Building maintenance will be conducted this Saturday from 9 AM to 5 PM. Please plan accordingly.",
      createdById: admin1.id,
      targetRole: null,
      priority: "important",
      expiresAt: null,
      createdAt: new Date(),
    };
    this.announcements.set(announcement1.id, announcement1);
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((user) => user.username === username);
  }

  async getUserWithoutPassword(id: string): Promise<UserWithoutPassword | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  async getUserWithRoomInfo(id: string): Promise<UserWithRoomInfo | undefined> {
    const user = await this.getUserWithoutPassword(id);
    if (!user) return undefined;

    const room = user.roomId ? this.rooms.get(user.roomId) : undefined;
    const building = user.buildingId ? this.buildings.get(user.buildingId) : undefined;

    return {
      ...user,
      room,
      building,
    };
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      roomId: insertUser.roomId || null,
      buildingId: insertUser.buildingId || null,
      email: insertUser.email || null,
      phone: insertUser.phone || null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<UserWithoutPassword[]> {
    return Array.from(this.users.values()).map(({ password, ...user }) => user);
  }

  async updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Building operations
  async getBuilding(id: string): Promise<Building | undefined> {
    return this.buildings.get(id);
  }

  async getAllBuildings(): Promise<Building[]> {
    return Array.from(this.buildings.values());
  }

  async createBuilding(insertBuilding: InsertBuilding): Promise<Building> {
    const id = randomUUID();
    const building: Building = {
      ...insertBuilding,
      id,
      description: insertBuilding.description || null,
      createdAt: new Date(),
    };
    this.buildings.set(id, building);
    return building;
  }

  async updateBuilding(id: string, data: Partial<InsertBuilding>): Promise<Building | undefined> {
    const building = this.buildings.get(id);
    if (!building) return undefined;

    const updatedBuilding = { ...building, ...data };
    this.buildings.set(id, updatedBuilding);
    return updatedBuilding;
  }

  async deleteBuilding(id: string): Promise<boolean> {
    return this.buildings.delete(id);
  }

  // Room operations
  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async getRoomsByBuilding(buildingId: string): Promise<Room[]> {
    return Array.from(this.rooms.values()).filter((room) => room.buildingId === buildingId);
  }

  async getAllRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = randomUUID();
    const room: Room = {
      ...insertRoom,
      id,
      floor: insertRoom.floor || null,
      monthlyRent: insertRoom.monthlyRent || null,
      description: insertRoom.description || null,
      occupied: 0,
      createdAt: new Date(),
    };
    this.rooms.set(id, room);
    return room;
  }

  async updateRoom(id: string, data: Partial<InsertRoom>): Promise<Room | undefined> {
    const room = this.rooms.get(id);
    if (!room) return undefined;

    const updatedRoom = { ...room, ...data };
    this.rooms.set(id, updatedRoom);
    return updatedRoom;
  }

  async deleteRoom(id: string): Promise<boolean> {
    return this.rooms.delete(id);
  }

  // Ticket operations
  async getTicket(id: string): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async getTicketWithDetails(id: string): Promise<TicketWithDetails | undefined> {
    const ticket = this.tickets.get(id);
    if (!ticket) return undefined;

    const createdBy = await this.getUserWithoutPassword(ticket.createdById);
    if (!createdBy) return undefined;

    const assignedTo = ticket.assignedToId
      ? await this.getUserWithoutPassword(ticket.assignedToId)
      : undefined;
    const room = ticket.roomId ? this.rooms.get(ticket.roomId) : undefined;
    const building = ticket.buildingId ? this.buildings.get(ticket.buildingId) : undefined;
    
    const comments = Array.from(this.ticketComments.values())
      .filter((c) => c.ticketId === id)
      .map((comment) => {
        const user = Array.from(this.users.values()).find((u) => u.id === comment.userId);
        const { password, ...userWithoutPassword } = user!;
        return { ...comment, user: userWithoutPassword };
      });

    return {
      ...ticket,
      createdBy,
      assignedTo,
      room,
      building,
      comments,
    };
  }

  async getTicketsByUser(userId: string): Promise<TicketWithDetails[]> {
    const userTickets = Array.from(this.tickets.values()).filter(
      (ticket) => ticket.createdById === userId
    );

    const detailedTickets = await Promise.all(
      userTickets.map((ticket) => this.getTicketWithDetails(ticket.id))
    );

    return detailedTickets.filter((t): t is TicketWithDetails => t !== undefined);
  }

  async getAllTickets(): Promise<TicketWithDetails[]> {
    const allTickets = Array.from(this.tickets.values());
    const detailedTickets = await Promise.all(
      allTickets.map((ticket) => this.getTicketWithDetails(ticket.id))
    );
    return detailedTickets.filter((t): t is TicketWithDetails => t !== undefined);
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const id = randomUUID();
    const ticket: Ticket = {
      ...insertTicket,
      id,
      assignedToId: insertTicket.assignedToId || null,
      roomId: insertTicket.roomId || null,
      buildingId: insertTicket.buildingId || null,
      imageUrl: insertTicket.imageUrl || null,
      resolvedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tickets.set(id, ticket);
    return ticket;
  }

  async updateTicket(id: string, data: UpdateTicket): Promise<Ticket | undefined> {
    const ticket = this.tickets.get(id);
    if (!ticket) return undefined;

    const updatedTicket = {
      ...ticket,
      ...data,
      updatedAt: new Date(),
      resolvedAt: data.status === "resolved" ? new Date() : ticket.resolvedAt,
    };
    this.tickets.set(id, updatedTicket);
    return updatedTicket;
  }

  async deleteTicket(id: string): Promise<boolean> {
    return this.tickets.delete(id);
  }

  // Announcement operations
  async getAnnouncement(id: string): Promise<Announcement | undefined> {
    return this.announcements.get(id);
  }

  async getAnnouncementsForUser(role: string): Promise<Announcement[]> {
    return Array.from(this.announcements.values()).filter(
      (announcement) => !announcement.targetRole || announcement.targetRole === role
    );
  }

  async getAllAnnouncements(): Promise<Announcement[]> {
    return Array.from(this.announcements.values());
  }

  async createAnnouncement(insertAnnouncement: InsertAnnouncement): Promise<Announcement> {
    const id = randomUUID();
    const announcement: Announcement = {
      ...insertAnnouncement,
      id,
      targetRole: insertAnnouncement.targetRole || null,
      expiresAt: insertAnnouncement.expiresAt || null,
      createdAt: new Date(),
    };
    this.announcements.set(id, announcement);
    return announcement;
  }

  async deleteAnnouncement(id: string): Promise<boolean> {
    return this.announcements.delete(id);
  }

  // Ticket comment operations
  async getCommentsByTicket(ticketId: string): Promise<TicketComment[]> {
    return Array.from(this.ticketComments.values()).filter(
      (comment) => comment.ticketId === ticketId
    );
  }

  async createTicketComment(insertComment: InsertTicketComment): Promise<TicketComment> {
    const id = randomUUID();
    const comment: TicketComment = {
      ...insertComment,
      id,
      createdAt: new Date(),
    };
    this.ticketComments.set(id, comment);
    return comment;
  }

  // Statistics
  async getStats() {
    const allUsers = Array.from(this.users.values());
    const allRooms = Array.from(this.rooms.values());
    const allTickets = Array.from(this.tickets.values());

    const totalUsers = allUsers.length;
    const tenants = allUsers.filter((u) => u.role === "tenant").length;
    const totalBuildings = this.buildings.size;
    const totalRooms = allRooms.length;
    const occupiedRooms = allRooms.filter((r) => r.occupied > 0).length;
    const occupancyRate = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
    const openTickets = allTickets.filter(
      (t) => t.status !== "resolved" && t.status !== "closed"
    ).length;
    const pendingTickets = allTickets.filter((t) => t.status === "pending").length;

    return {
      totalUsers,
      tenants,
      totalBuildings,
      totalRooms,
      occupiedRooms,
      occupancyRate,
      openTickets,
      pendingTickets,
    };
  }
}

export const storage = new MemStorage();
