import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Building2, Home, LogOut, Plus, AlertCircle, Clock, CheckCircle2, User, Mail, Phone } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserWithRoomInfo, TicketWithDetails, Announcement } from "@shared/schema";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function TenantPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<UserWithRoomInfo | null>(null);
  const [isCreateTicketOpen, setIsCreateTicketOpen] = useState(false);
  
  // New ticket form state
  const [newTicket, setNewTicket] = useState({
    title: "",
    description: "",
    category: "general" as "plumbing" | "electrical" | "hvac" | "general" | "other",
    priority: "medium" as "low" | "medium" | "high" | "urgent",
  });

  useEffect(() => {
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      setCurrentUser(JSON.parse(userStr));
    } else {
      setLocation('/login');
    }
  }, [setLocation]);

  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: ['/api/tickets/my-tickets', currentUser?.id],
    queryFn: async () => {
      if (!currentUser) return [];
      const response = await fetch(`/api/tickets/my-tickets?userId=${currentUser.id}`);
      if (!response.ok) throw new Error('Failed to fetch tickets');
      return response.json();
    },
    enabled: !!currentUser,
  });

  const { data: announcements, isLoading: announcementsLoading } = useQuery({
    queryKey: ['/api/announcements', currentUser?.role],
    queryFn: async () => {
      if (!currentUser) return [];
      const response = await fetch(`/api/announcements?role=${currentUser.role}`);
      if (!response.ok) throw new Error('Failed to fetch announcements');
      return response.json();
    },
    enabled: !!currentUser,
  });

  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: typeof newTicket) => {
      if (!currentUser) throw new Error('User not authenticated');
      return await apiRequest('POST', '/api/tickets', {
        ...ticketData,
        createdById: currentUser.id,
        roomId: currentUser.roomId || undefined,
        buildingId: currentUser.buildingId || undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tickets/my-tickets', currentUser?.id] });
      setIsCreateTicketOpen(false);
      setNewTicket({ title: "", description: "", category: "general", priority: "medium" });
      toast({
        title: "Ticket Created",
        description: "Your maintenance request has been submitted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('authToken');
    setLocation('/');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'bg-green-500/10 text-green-700 dark:text-green-400';
      case 'in_progress': return 'bg-blue-500/10 text-blue-700 dark:text-blue-400';
      case 'pending': return 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/10 text-red-700 dark:text-red-400';
      case 'high': return 'bg-orange-500/10 text-orange-700 dark:text-orange-400';
      case 'medium': return 'bg-blue-500/10 text-blue-700 dark:text-blue-400';
      case 'low': return 'bg-gray-500/10 text-gray-700 dark:text-gray-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-lg font-semibold">DormHub</h1>
                <p className="text-xs text-muted-foreground">Resident Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{currentUser.fullName}</p>
                <p className="text-xs text-muted-foreground capitalize">{currentUser.role}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Welcome back, {currentUser.fullName.split(' ')[0]}!</h2>
          <p className="text-muted-foreground">Manage your room and maintenance requests</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Room Info & Profile */}
          <div className="lg:col-span-1 space-y-6">
            {/* Room Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="h-5 w-5" />
                  Your Room
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentUser.room && currentUser.building ? (
                  <>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Room Number</p>
                      <p className="text-2xl font-bold" data-testid="text-room-number">{currentUser.room.roomNumber}</p>
                    </div>
                    <Separator />
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Building</p>
                      <p className="font-medium" data-testid="text-building">{currentUser.building.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Address</p>
                      <p className="text-sm">{currentUser.building.address}</p>
                    </div>
                    {currentUser.room.monthlyRent && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Monthly Rent</p>
                        <p className="font-medium">${currentUser.room.monthlyRent}</p>
                      </div>
                    )}
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">No room assigned</p>
                )}
              </CardContent>
            </Card>

            {/* Profile Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {currentUser.email && (
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{currentUser.email}</span>
                  </div>
                )}
                {currentUser.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{currentUser.phone}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Tickets & Announcements */}
          <div className="lg:col-span-2 space-y-6">
            {/* Announcements */}
            {!announcementsLoading && announcements && announcements.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Announcements</CardTitle>
                  <CardDescription>Important updates for residents</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {(announcements as Announcement[]).map((announcement) => (
                    <div key={announcement.id} className="p-4 rounded-lg bg-muted/50 border">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h4 className="font-medium mb-1">{announcement.title}</h4>
                          <p className="text-sm text-muted-foreground">{announcement.content}</p>
                        </div>
                        {announcement.priority !== 'normal' && (
                          <Badge variant={announcement.priority === 'urgent' ? 'destructive' : 'default'}>
                            {announcement.priority}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Maintenance Tickets */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>My Maintenance Requests</CardTitle>
                    <CardDescription>Track your submitted tickets</CardDescription>
                  </div>
                  <Dialog open={isCreateTicketOpen} onOpenChange={setIsCreateTicketOpen}>
                    <DialogTrigger asChild>
                      <Button data-testid="button-create-ticket">
                        <Plus className="h-4 w-4 mr-2" />
                        New Request
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Submit Maintenance Request</DialogTitle>
                        <DialogDescription>
                          Describe the issue you're experiencing
                        </DialogDescription>
                      </DialogHeader>
                      <form onSubmit={(e) => {
                        e.preventDefault();
                        createTicketMutation.mutate(newTicket);
                      }} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="title">Title</Label>
                          <Input
                            id="title"
                            placeholder="Brief description of the issue"
                            value={newTicket.title}
                            onChange={(e) => setNewTicket({ ...newTicket, title: e.target.value })}
                            required
                            data-testid="input-ticket-title"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="category">Category</Label>
                          <Select value={newTicket.category} onValueChange={(value: any) => setNewTicket({ ...newTicket, category: value })}>
                            <SelectTrigger data-testid="select-category">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="plumbing">Plumbing</SelectItem>
                              <SelectItem value="electrical">Electrical</SelectItem>
                              <SelectItem value="hvac">HVAC</SelectItem>
                              <SelectItem value="general">General Maintenance</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="priority">Priority</Label>
                          <Select value={newTicket.priority} onValueChange={(value: any) => setNewTicket({ ...newTicket, priority: value })}>
                            <SelectTrigger data-testid="select-priority">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">Low</SelectItem>
                              <SelectItem value="medium">Medium</SelectItem>
                              <SelectItem value="high">High</SelectItem>
                              <SelectItem value="urgent">Urgent</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="description">Description</Label>
                          <Textarea
                            id="description"
                            placeholder="Provide detailed information about the issue"
                            value={newTicket.description}
                            onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                            rows={4}
                            required
                            data-testid="textarea-description"
                          />
                        </div>
                        <div className="flex gap-2 justify-end">
                          <Button type="button" variant="outline" onClick={() => setIsCreateTicketOpen(false)}>
                            Cancel
                          </Button>
                          <Button type="submit" disabled={createTicketMutation.isPending} data-testid="button-submit-ticket">
                            {createTicketMutation.isPending ? "Submitting..." : "Submit Request"}
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {ticketsLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-24 rounded-lg bg-muted/50 animate-pulse" />
                    ))}
                  </div>
                ) : tickets && (tickets as TicketWithDetails[]).length > 0 ? (
                  <div className="space-y-3">
                    {(tickets as TicketWithDetails[]).map((ticket) => (
                      <div key={ticket.id} className="p-4 rounded-lg border hover-elevate transition-all" data-testid={`ticket-${ticket.id}`}>
                        <div className="flex items-start justify-between gap-4 mb-3">
                          <div className="flex-1">
                            <h4 className="font-medium mb-1">{ticket.title}</h4>
                            <p className="text-sm text-muted-foreground line-clamp-2">{ticket.description}</p>
                          </div>
                          <div className="flex flex-col gap-2 items-end">
                            <Badge className={getStatusColor(ticket.status)}>
                              {ticket.status.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                              {ticket.priority}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="capitalize">{ticket.category}</span>
                          <span>•</span>
                          <span>{new Date(ticket.createdAt).toLocaleDateString()}</span>
                          {ticket.status === 'resolved' && (
                            <>
                              <span>•</span>
                              <span className="flex items-center gap-1 text-green-600 dark:text-green-400">
                                <CheckCircle2 className="h-3 w-3" />
                                Resolved
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-4">No maintenance requests yet</p>
                    <Button onClick={() => setIsCreateTicketOpen(true)} data-testid="button-empty-create">
                      <Plus className="h-4 w-4 mr-2" />
                      Submit Your First Request
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
