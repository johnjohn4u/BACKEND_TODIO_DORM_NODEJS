import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Building2, LogOut, Plus, Users, Home, Megaphone, BarChart3 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserWithRoomInfo, User, Building, Room, Ticket } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function AdminPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<UserWithRoomInfo | null>(null);
  
  // Dialog states
  const [isCreateBuildingOpen, setIsCreateBuildingOpen] = useState(false);
  const [isCreateRoomOpen, setIsCreateRoomOpen] = useState(false);
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false);
  const [isCreateAnnouncementOpen, setIsCreateAnnouncementOpen] = useState(false);

  // Form states
  const [newBuilding, setNewBuilding] = useState({ name: "", address: "", totalRooms: 0, description: "" });
  const [newRoom, setNewRoom] = useState({ roomNumber: "", buildingId: "", capacity: 1, floor: 1, monthlyRent: 0, description: "" });
  const [newUser, setNewUser] = useState({ username: "", password: "", fullName: "", role: "tenant" as "tenant" | "admin" | "helpdesk", email: "", phone: "", roomId: "", buildingId: "" });
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", content: "", targetRole: "" as "" | "tenant" | "admin" | "helpdesk", priority: "normal" as "normal" | "important" | "urgent" });

  useEffect(() => {
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      const user = JSON.parse(userStr);
      if (user.role !== 'admin') {
        setLocation('/login');
      } else {
        setCurrentUser(user);
      }
    } else {
      setLocation('/login');
    }
  }, [setLocation]);

  // Queries
  const { data: stats } = useQuery({ queryKey: ['/api/admin/stats'], enabled: !!currentUser });
  const { data: buildings } = useQuery({ queryKey: ['/api/buildings'], enabled: !!currentUser });
  const { data: rooms } = useQuery({ queryKey: ['/api/rooms'], enabled: !!currentUser });
  const { data: users } = useQuery({ queryKey: ['/api/users'], enabled: !!currentUser });
  const { data: tickets } = useQuery({ queryKey: ['/api/tickets'], enabled: !!currentUser });

  // Mutations
  const createBuildingMutation = useMutation({
    mutationFn: (data: typeof newBuilding) => apiRequest('POST', '/api/buildings', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/buildings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      setIsCreateBuildingOpen(false);
      setNewBuilding({ name: "", address: "", totalRooms: 0, description: "" });
      toast({ title: "Success", description: "Building created successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const createRoomMutation = useMutation({
    mutationFn: (data: typeof newRoom) => apiRequest('POST', '/api/rooms', { ...data, monthlyRent: Number(data.monthlyRent), capacity: Number(data.capacity), floor: Number(data.floor) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rooms'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      setIsCreateRoomOpen(false);
      setNewRoom({ roomNumber: "", buildingId: "", capacity: 1, floor: 1, monthlyRent: 0, description: "" });
      toast({ title: "Success", description: "Room created successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const createUserMutation = useMutation({
    mutationFn: (data: typeof newUser) => apiRequest('POST', '/api/users', {
      ...data,
      roomId: data.roomId || undefined,
      buildingId: data.buildingId || undefined,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      setIsCreateUserOpen(false);
      setNewUser({ username: "", password: "", fullName: "", role: "tenant", email: "", phone: "", roomId: "", buildingId: "" });
      toast({ title: "Success", description: "User created successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const createAnnouncementMutation = useMutation({
    mutationFn: (data: typeof newAnnouncement) => {
      if (!currentUser) throw new Error('User not authenticated');
      return apiRequest('POST', '/api/announcements', {
        ...data,
        createdById: currentUser.id,
        targetRole: data.targetRole || undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/announcements'] });
      setIsCreateAnnouncementOpen(false);
      setNewAnnouncement({ title: "", content: "", targetRole: "", priority: "normal" });
      toast({ title: "Success", description: "Announcement posted successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('authToken');
    setLocation('/');
  };

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-lg font-semibold">DormHub</h1>
                <p className="text-xs text-muted-foreground">Admin Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{currentUser.fullName}</p>
                <p className="text-xs text-muted-foreground capitalize">{currentUser.role}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Admin Dashboard</h2>
          <p className="text-muted-foreground">Manage dormitories, rooms, and residents</p>
        </div>

        {/* Statistics */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Total Users</CardDescription>
                <CardTitle className="text-3xl" data-testid="stat-users">{stats.totalUsers || 0}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>{stats.tenants || 0} tenants</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Buildings</CardDescription>
                <CardTitle className="text-3xl" data-testid="stat-buildings">{stats.totalBuildings || 0}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Building2 className="h-4 w-4" />
                  <span>{stats.totalRooms || 0} rooms total</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Occupancy</CardDescription>
                <CardTitle className="text-3xl" data-testid="stat-occupancy">{stats.occupancyRate || 0}%</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Home className="h-4 w-4" />
                  <span>{stats.occupiedRooms || 0} / {stats.totalRooms || 0} occupied</span>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Open Tickets</CardDescription>
                <CardTitle className="text-3xl" data-testid="stat-tickets">{stats.openTickets || 0}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <BarChart3 className="h-4 w-4" />
                  <span>{stats.pendingTickets || 0} pending</span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Management Tabs */}
        <Tabs defaultValue="buildings" className="space-y-4">
          <TabsList>
            <TabsTrigger value="buildings" data-testid="tab-buildings">Buildings</TabsTrigger>
            <TabsTrigger value="rooms" data-testid="tab-rooms">Rooms</TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">Users</TabsTrigger>
            <TabsTrigger value="announcements" data-testid="tab-announcements">Announcements</TabsTrigger>
          </TabsList>

          {/* Buildings Tab */}
          <TabsContent value="buildings" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold">Buildings Management</h3>
              <Dialog open={isCreateBuildingOpen} onOpenChange={setIsCreateBuildingOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-create-building">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Building
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Building</DialogTitle>
                    <DialogDescription>Add a new dormitory building to the system</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createBuildingMutation.mutate(newBuilding); }} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="building-name">Building Name</Label>
                      <Input id="building-name" value={newBuilding.name} onChange={(e) => setNewBuilding({ ...newBuilding, name: e.target.value })} required data-testid="input-building-name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="building-address">Address</Label>
                      <Input id="building-address" value={newBuilding.address} onChange={(e) => setNewBuilding({ ...newBuilding, address: e.target.value })} required data-testid="input-building-address" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="building-total-rooms">Total Rooms</Label>
                      <Input id="building-total-rooms" type="number" value={newBuilding.totalRooms} onChange={(e) => setNewBuilding({ ...newBuilding, totalRooms: parseInt(e.target.value) })} required data-testid="input-building-total-rooms" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="building-description">Description</Label>
                      <Textarea id="building-description" value={newBuilding.description} onChange={(e) => setNewBuilding({ ...newBuilding, description: e.target.value })} rows={3} />
                    </div>
                    <div className="flex gap-2 justify-end">
                      <Button type="button" variant="outline" onClick={() => setIsCreateBuildingOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={createBuildingMutation.isPending} data-testid="button-submit-building">
                        {createBuildingMutation.isPending ? "Creating..." : "Create Building"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            <Card>
              <CardContent className="pt-6">
                {buildings && (buildings as Building[]).length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Address</TableHead>
                        <TableHead>Total Rooms</TableHead>
                        <TableHead>Created</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(buildings as Building[]).map((building) => (
                        <TableRow key={building.id}>
                          <TableCell className="font-medium">{building.name}</TableCell>
                          <TableCell>{building.address}</TableCell>
                          <TableCell>{building.totalRooms}</TableCell>
                          <TableCell>{new Date(building.createdAt).toLocaleDateString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">No buildings yet. Create your first building to get started.</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Rooms Tab */}
          <TabsContent value="rooms" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold">Rooms Management</h3>
              <Dialog open={isCreateRoomOpen} onOpenChange={setIsCreateRoomOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-create-room">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Room
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Room</DialogTitle>
                    <DialogDescription>Add a new room to a building</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createRoomMutation.mutate(newRoom); }} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="room-number">Room Number</Label>
                      <Input id="room-number" value={newRoom.roomNumber} onChange={(e) => setNewRoom({ ...newRoom, roomNumber: e.target.value })} required data-testid="input-room-number" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="room-building">Building</Label>
                      <Select value={newRoom.buildingId} onValueChange={(value) => setNewRoom({ ...newRoom, buildingId: value })}>
                        <SelectTrigger data-testid="select-room-building">
                          <SelectValue placeholder="Select building" />
                        </SelectTrigger>
                        <SelectContent>
                          {buildings && (buildings as Building[]).map((building) => (
                            <SelectItem key={building.id} value={building.id}>{building.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="room-capacity">Capacity</Label>
                        <Input id="room-capacity" type="number" value={newRoom.capacity} onChange={(e) => setNewRoom({ ...newRoom, capacity: parseInt(e.target.value) })} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="room-floor">Floor</Label>
                        <Input id="room-floor" type="number" value={newRoom.floor} onChange={(e) => setNewRoom({ ...newRoom, floor: parseInt(e.target.value) })} required />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="room-rent">Monthly Rent ($)</Label>
                      <Input id="room-rent" type="number" value={newRoom.monthlyRent} onChange={(e) => setNewRoom({ ...newRoom, monthlyRent: parseInt(e.target.value) })} />
                    </div>
                    <div className="flex gap-2 justify-end">
                      <Button type="button" variant="outline" onClick={() => setIsCreateRoomOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={createRoomMutation.isPending} data-testid="button-submit-room">
                        {createRoomMutation.isPending ? "Creating..." : "Create Room"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            <Card>
              <CardContent className="pt-6">
                {rooms && (rooms as Room[]).length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Room Number</TableHead>
                        <TableHead>Floor</TableHead>
                        <TableHead>Capacity</TableHead>
                        <TableHead>Occupied</TableHead>
                        <TableHead>Rent</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(rooms as Room[]).map((room) => (
                        <TableRow key={room.id}>
                          <TableCell className="font-medium">{room.roomNumber}</TableCell>
                          <TableCell>Floor {room.floor}</TableCell>
                          <TableCell>{room.capacity}</TableCell>
                          <TableCell>{room.occupied}</TableCell>
                          <TableCell>${room.monthlyRent}</TableCell>
                          <TableCell>
                            <Badge variant={room.occupied >= room.capacity ? "destructive" : "default"}>
                              {room.occupied >= room.capacity ? "Full" : "Available"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">No rooms yet. Create buildings first, then add rooms.</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold">Users Management</h3>
              <Dialog open={isCreateUserOpen} onOpenChange={setIsCreateUserOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-create-user">
                    <Plus className="h-4 w-4 mr-2" />
                    Add User
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New User</DialogTitle>
                    <DialogDescription>Add a new user to the system</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createUserMutation.mutate(newUser); }} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="user-username">Username</Label>
                        <Input id="user-username" value={newUser.username} onChange={(e) => setNewUser({ ...newUser, username: e.target.value })} required data-testid="input-user-username" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="user-password">Password</Label>
                        <Input id="user-password" type="password" value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} required />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="user-fullname">Full Name</Label>
                      <Input id="user-fullname" value={newUser.fullName} onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="user-role">Role</Label>
                      <Select value={newUser.role} onValueChange={(value: any) => setNewUser({ ...newUser, role: value })}>
                        <SelectTrigger data-testid="select-user-role">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="tenant">Tenant</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="helpdesk">Help Desk</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {newUser.role === 'tenant' && (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="user-building">Building (Optional)</Label>
                          <Select value={newUser.buildingId} onValueChange={(value) => setNewUser({ ...newUser, buildingId: value })}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select building" />
                            </SelectTrigger>
                            <SelectContent>
                              {buildings && (buildings as Building[]).map((building) => (
                                <SelectItem key={building.id} value={building.id}>{building.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="user-room">Room (Optional)</Label>
                          <Select value={newUser.roomId} onValueChange={(value) => setNewUser({ ...newUser, roomId: value })}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select room" />
                            </SelectTrigger>
                            <SelectContent>
                              {rooms && (rooms as Room[]).map((room) => (
                                <SelectItem key={room.id} value={room.id}>{room.roomNumber}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}
                    <div className="flex gap-2 justify-end">
                      <Button type="button" variant="outline" onClick={() => setIsCreateUserOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={createUserMutation.isPending} data-testid="button-submit-user">
                        {createUserMutation.isPending ? "Creating..." : "Create User"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
            <Card>
              <CardContent className="pt-6">
                {users && (users as User[]).length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Full Name</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Created</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(users as User[]).map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.username}</TableCell>
                          <TableCell>{user.fullName}</TableCell>
                          <TableCell><Badge className="capitalize">{user.role}</Badge></TableCell>
                          <TableCell>{new Date(user.createdAt).toLocaleDateString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">No users yet.</div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Announcements Tab */}
          <TabsContent value="announcements" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold">Announcements</h3>
              <Dialog open={isCreateAnnouncementOpen} onOpenChange={setIsCreateAnnouncementOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-create-announcement">
                    <Megaphone className="h-4 w-4 mr-2" />
                    Post Announcement
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Post Announcement</DialogTitle>
                    <DialogDescription>Send a message to all or specific user roles</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={(e) => { e.preventDefault(); createAnnouncementMutation.mutate(newAnnouncement); }} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="announcement-title">Title</Label>
                      <Input id="announcement-title" value={newAnnouncement.title} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })} required data-testid="input-announcement-title" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="announcement-content">Content</Label>
                      <Textarea id="announcement-content" value={newAnnouncement.content} onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })} rows={4} required data-testid="textarea-announcement-content" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="announcement-target">Target Role</Label>
                        <Select value={newAnnouncement.targetRole} onValueChange={(value: any) => setNewAnnouncement({ ...newAnnouncement, targetRole: value })}>
                          <SelectTrigger data-testid="select-announcement-target">
                            <SelectValue placeholder="All users" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="">All Users</SelectItem>
                            <SelectItem value="tenant">Tenants Only</SelectItem>
                            <SelectItem value="admin">Admins Only</SelectItem>
                            <SelectItem value="helpdesk">Help Desk Only</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="announcement-priority">Priority</Label>
                        <Select value={newAnnouncement.priority} onValueChange={(value: any) => setNewAnnouncement({ ...newAnnouncement, priority: value })}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="normal">Normal</SelectItem>
                            <SelectItem value="important">Important</SelectItem>
                            <SelectItem value="urgent">Urgent</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <Button type="button" variant="outline" onClick={() => setIsCreateAnnouncementOpen(false)}>Cancel</Button>
                      <Button type="submit" disabled={createAnnouncementMutation.isPending} data-testid="button-submit-announcement">
                        {createAnnouncementMutation.isPending ? "Posting..." : "Post Announcement"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
