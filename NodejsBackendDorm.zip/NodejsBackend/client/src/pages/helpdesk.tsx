import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Building2, LogOut, Search, Filter, MessageSquare, User as UserIcon } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserWithRoomInfo, TicketWithDetails, User } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";

export default function HelpDeskPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState<UserWithRoomInfo | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<TicketWithDetails | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [newComment, setNewComment] = useState("");

  useEffect(() => {
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      const user = JSON.parse(userStr);
      if (user.role !== 'helpdesk') {
        setLocation('/login');
      } else {
        setCurrentUser(user);
      }
    } else {
      setLocation('/login');
    }
  }, [setLocation]);

  const { data: tickets, isLoading } = useQuery({
    queryKey: ['/api/tickets'],
    enabled: !!currentUser,
  });

  const { data: users } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!currentUser,
  });

  const updateTicketMutation = useMutation({
    mutationFn: async ({ ticketId, data }: { ticketId: string; data: any }) => {
      return await apiRequest('PATCH', `/api/tickets/${ticketId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      toast({ title: "Success", description: "Ticket updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ ticketId, comment }: { ticketId: string; comment: string }) => {
      if (!currentUser) throw new Error('User not authenticated');
      return await apiRequest('POST', `/api/tickets/${ticketId}/comments`, { 
        comment,
        userId: currentUser.id,
        isStatusUpdate: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tickets'] });
      setNewComment("");
      toast({ title: "Success", description: "Comment added successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('authToken');
    setLocation('/');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'bg-green-500/10 text-green-700 dark:text-green-400';
      case 'in_progress': return 'bg-blue-500/10 text-blue-700 dark:text-blue-400';
      case 'pending': return 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400';
      case 'closed': return 'bg-gray-500/10 text-gray-700 dark:text-gray-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/10 text-red-700 dark:text-red-400';
      case 'high': return 'bg-orange-500/10 text-orange-700 dark:text-orange-400';
      case 'medium': return 'bg-blue-500/10 text-blue-700 dark:text-blue-400';
      case 'low': return 'bg-gray-500/10 text-gray-700 dark:text-gray-400';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const filteredTickets = tickets
    ? (tickets as TicketWithDetails[]).filter((ticket) => {
        const matchesStatus = filterStatus === "all" || ticket.status === filterStatus;
        const matchesSearch = 
          searchQuery === "" ||
          ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ticket.description.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesStatus && matchesSearch;
      })
    : [];

  const pendingTickets = filteredTickets.filter(t => t.status === 'pending');
  const inProgressTickets = filteredTickets.filter(t => t.status === 'in_progress');
  const resolvedTickets = filteredTickets.filter(t => t.status === 'resolved' || t.status === 'closed');

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-lg font-semibold">DormHub</h1>
                <p className="text-xs text-muted-foreground">Help Desk Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{currentUser.fullName}</p>
                <p className="text-xs text-muted-foreground capitalize">{currentUser.role}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Support Tickets</h2>
          <p className="text-muted-foreground">Manage and resolve maintenance requests</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Pending</CardDescription>
              <CardTitle className="text-3xl text-yellow-600 dark:text-yellow-400" data-testid="stat-pending">
                {pendingTickets.length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>In Progress</CardDescription>
              <CardTitle className="text-3xl text-blue-600 dark:text-blue-400" data-testid="stat-in-progress">
                {inProgressTickets.length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Resolved</CardDescription>
              <CardTitle className="text-3xl text-green-600 dark:text-green-400" data-testid="stat-resolved">
                {resolvedTickets.length}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tickets..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  data-testid="input-search"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-48" data-testid="select-filter">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tickets</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tickets List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h3 className="text-xl font-semibold mb-4">Tickets</h3>
            <div className="space-y-3">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-32 rounded-lg bg-muted/50 animate-pulse" />
                ))
              ) : filteredTickets.length > 0 ? (
                filteredTickets.map((ticket) => (
                  <Card
                    key={ticket.id}
                    className={`cursor-pointer hover-elevate transition-all ${selectedTicket?.id === ticket.id ? 'border-primary' : ''}`}
                    onClick={() => setSelectedTicket(ticket)}
                    data-testid={`ticket-card-${ticket.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <div className="flex-1">
                          <h4 className="font-medium mb-1">{ticket.title}</h4>
                          <p className="text-sm text-muted-foreground line-clamp-2">{ticket.description}</p>
                        </div>
                        <div className="flex flex-col gap-2 items-end">
                          <Badge className={getStatusColor(ticket.status)}>
                            {ticket.status.replace('_', ' ')}
                          </Badge>
                          <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                            {ticket.priority}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="capitalize">{ticket.category}</span>
                        <span>•</span>
                        <span>{ticket.createdBy.fullName}</span>
                        {ticket.room && (
                          <>
                            <span>•</span>
                            <span>Room {ticket.room.roomNumber}</span>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="p-12 text-center text-muted-foreground">
                    No tickets found
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Ticket Details */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Ticket Details</h3>
            {selectedTicket ? (
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <CardTitle>{selectedTicket.title}</CardTitle>
                      <CardDescription className="mt-2">
                        Submitted by {selectedTicket.createdBy.fullName} on {new Date(selectedTicket.createdAt).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Badge className={getStatusColor(selectedTicket.status)}>
                        {selectedTicket.status.replace('_', ' ')}
                      </Badge>
                      <Badge variant="outline" className={getPriorityColor(selectedTicket.priority)}>
                        {selectedTicket.priority}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Description */}
                  <div>
                    <h4 className="font-medium mb-2">Description</h4>
                    <p className="text-sm text-muted-foreground">{selectedTicket.description}</p>
                  </div>

                  <Separator />

                  {/* Details */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Category</p>
                      <p className="font-medium capitalize">{selectedTicket.category}</p>
                    </div>
                    {selectedTicket.room && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Room</p>
                        <p className="font-medium">{selectedTicket.room.roomNumber}</p>
                      </div>
                    )}
                    {selectedTicket.building && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Building</p>
                        <p className="font-medium">{selectedTicket.building.name}</p>
                      </div>
                    )}
                    {selectedTicket.assignedTo && (
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Assigned To</p>
                        <p className="font-medium">{selectedTicket.assignedTo.fullName}</p>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Actions */}
                  <div className="space-y-4">
                    <h4 className="font-medium">Update Ticket</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select
                          value={selectedTicket.status}
                          onValueChange={(value) => {
                            updateTicketMutation.mutate({
                              ticketId: selectedTicket.id,
                              data: { status: value },
                            });
                          }}
                        >
                          <SelectTrigger data-testid="select-ticket-status">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="resolved">Resolved</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Priority</Label>
                        <Select
                          value={selectedTicket.priority}
                          onValueChange={(value) => {
                            updateTicketMutation.mutate({
                              ticketId: selectedTicket.id,
                              data: { priority: value },
                            });
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="urgent">Urgent</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    {users && (
                      <div className="space-y-2">
                        <Label>Assign To</Label>
                        <Select
                          value={selectedTicket.assignedToId || ""}
                          onValueChange={(value) => {
                            updateTicketMutation.mutate({
                              ticketId: selectedTicket.id,
                              data: { assignedToId: value },
                            });
                          }}
                        >
                          <SelectTrigger data-testid="select-assign-to">
                            <SelectValue placeholder="Select staff member" />
                          </SelectTrigger>
                          <SelectContent>
                            {(users as User[])
                              .filter((u) => u.role === 'helpdesk' || u.role === 'admin')
                              .map((user) => (
                                <SelectItem key={user.id} value={user.id}>
                                  {user.fullName}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Comments */}
                  <div className="space-y-4">
                    <h4 className="font-medium flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      Comments
                    </h4>
                    {selectedTicket.comments && selectedTicket.comments.length > 0 ? (
                      <div className="space-y-3">
                        {selectedTicket.comments.map((comment) => (
                          <div key={comment.id} className="p-3 rounded-lg bg-muted/50">
                            <div className="flex items-center gap-2 mb-2">
                              <UserIcon className="h-4 w-4" />
                              <span className="font-medium text-sm">{comment.user.fullName}</span>
                              <span className="text-xs text-muted-foreground">
                                {new Date(comment.createdAt).toLocaleString()}
                              </span>
                            </div>
                            <p className="text-sm">{comment.comment}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No comments yet</p>
                    )}
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a comment..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        data-testid="input-comment"
                      />
                      <Button
                        onClick={() => {
                          if (newComment.trim()) {
                            addCommentMutation.mutate({
                              ticketId: selectedTicket.id,
                              comment: newComment,
                            });
                          }
                        }}
                        disabled={!newComment.trim() || addCommentMutation.isPending}
                        data-testid="button-add-comment"
                      >
                        {addCommentMutation.isPending ? "Sending..." : "Send"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-12 text-center text-muted-foreground">
                  Select a ticket to view details
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
