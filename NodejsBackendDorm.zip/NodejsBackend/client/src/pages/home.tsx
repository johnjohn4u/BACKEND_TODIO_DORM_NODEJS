import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Building2, Shield, Headphones, ArrowRight, CheckCircle2 } from "lucide-react";
import { useLocation } from "wouter";

export default function HomePage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/10 via-background to-background">
        <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 mb-8">
              <Building2 className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium text-primary">Modern Dorm Management</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              Welcome to
              <span className="block text-primary mt-2">DormHub</span>
            </h1>
            
            <p className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed">
              Streamline your dormitory operations with our comprehensive management platform.
              From maintenance requests to room assignments, we've got you covered.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                className="text-lg px-8 py-6 gap-2"
                onClick={() => setLocation('/login')}
                data-testid="button-get-started"
              >
                Get Started <ArrowRight className="h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 py-6"
                data-testid="button-learn-more"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Everything You Need</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Powerful features designed for students, administrators, and support staff
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Tenant Features */}
          <Card className="p-8 hover-elevate transition-all">
            <div className="h-14 w-14 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
              <Building2 className="h-7 w-7 text-primary" />
            </div>
            <h3 className="text-2xl font-semibold mb-3">For Residents</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Access your room information, submit maintenance requests, and stay updated with announcements.
            </p>
            <ul className="space-y-3">
              {['View room details', 'Submit maintenance tickets', 'Track request status', 'Receive notifications'].map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Admin Features */}
          <Card className="p-8 hover-elevate transition-all border-primary/20">
            <div className="h-14 w-14 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
              <Shield className="h-7 w-7 text-primary" />
            </div>
            <h3 className="text-2xl font-semibold mb-3">For Administrators</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Manage dormitories, assign rooms, oversee tenants, and monitor facility operations.
            </p>
            <ul className="space-y-3">
              {['Manage buildings & rooms', 'Assign tenants', 'View statistics', 'Post announcements'].map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Help Desk Features */}
          <Card className="p-8 hover-elevate transition-all">
            <div className="h-14 w-14 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
              <Headphones className="h-7 w-7 text-primary" />
            </div>
            <h3 className="text-2xl font-semibold mb-3">For Support Staff</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Efficiently handle maintenance requests, track progress, and ensure resident satisfaction.
            </p>
            <ul className="space-y-3">
              {['Manage support tickets', 'Assign priorities', 'Update ticket status', 'Communicate with residents'].map((feature) => (
                <li key={feature} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <Card className="p-12 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join thousands of students and administrators using DormHub for seamless dormitory management.
            </p>
            <Button 
              size="lg" 
              className="text-lg px-8 py-6 gap-2"
              onClick={() => setLocation('/login')}
              data-testid="button-cta-login"
            >
              Sign In Now <ArrowRight className="h-5 w-5" />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
