import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with role-based access
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull(), // 'tenant' | 'admin' | 'helpdesk'
  email: text("email"),
  phone: text("phone"),
  roomId: varchar("room_id"),
  buildingId: varchar("building_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Buildings table
export const buildings = pgTable("buildings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  totalRooms: integer("total_rooms").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Rooms table
export const rooms = pgTable("rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomNumber: text("room_number").notNull(),
  buildingId: varchar("building_id").notNull(),
  capacity: integer("capacity").notNull().default(1),
  occupied: integer("occupied").notNull().default(0),
  floor: integer("floor"),
  monthlyRent: integer("monthly_rent"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Maintenance tickets table
export const tickets = pgTable("tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default('pending'), // 'pending' | 'in_progress' | 'resolved' | 'closed'
  priority: text("priority").notNull().default('medium'), // 'low' | 'medium' | 'high' | 'urgent'
  category: text("category").notNull(), // 'plumbing' | 'electrical' | 'hvac' | 'general' | 'other'
  createdById: varchar("created_by_id").notNull(),
  assignedToId: varchar("assigned_to_id"),
  roomId: varchar("room_id"),
  buildingId: varchar("building_id"),
  imageUrl: text("image_url"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Announcements table
export const announcements = pgTable("announcements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdById: varchar("created_by_id").notNull(),
  targetRole: text("target_role"), // null means all users, or 'tenant' | 'admin' | 'helpdesk'
  priority: text("priority").notNull().default('normal'), // 'normal' | 'important' | 'urgent'
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Ticket comments/updates table
export const ticketComments = pgTable("ticket_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticketId: varchar("ticket_id").notNull(),
  userId: varchar("user_id").notNull(),
  comment: text("comment").notNull(),
  isStatusUpdate: boolean("is_status_update").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  role: z.enum(['tenant', 'admin', 'helpdesk']),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

export const loginSchema = z.object({
  username: z.string().min(1, 'Username is required'),
  password: z.string().min(1, 'Password is required'),
});

export const insertBuildingSchema = createInsertSchema(buildings).omit({
  id: true,
  createdAt: true,
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true,
  createdAt: true,
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  resolvedAt: true,
}).extend({
  status: z.enum(['pending', 'in_progress', 'resolved', 'closed']).default('pending'),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).default('medium'),
  category: z.enum(['plumbing', 'electrical', 'hvac', 'general', 'other']),
});

export const updateTicketSchema = z.object({
  status: z.enum(['pending', 'in_progress', 'resolved', 'closed']).optional(),
  assignedToId: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
});

export const insertAnnouncementSchema = createInsertSchema(announcements).omit({
  id: true,
  createdAt: true,
}).extend({
  targetRole: z.enum(['tenant', 'admin', 'helpdesk']).optional(),
  priority: z.enum(['normal', 'important', 'urgent']).default('normal'),
});

export const insertTicketCommentSchema = createInsertSchema(ticketComments).omit({
  id: true,
  createdAt: true,
});

// TypeScript types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type UserWithoutPassword = Omit<User, 'password'>;
export type LoginCredentials = z.infer<typeof loginSchema>;

export type InsertBuilding = z.infer<typeof insertBuildingSchema>;
export type Building = typeof buildings.$inferSelect;

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof rooms.$inferSelect;

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;
export type UpdateTicket = z.infer<typeof updateTicketSchema>;

export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;
export type Announcement = typeof announcements.$inferSelect;

export type InsertTicketComment = z.infer<typeof insertTicketCommentSchema>;
export type TicketComment = typeof ticketComments.$inferSelect;

// Extended types for API responses
export type TicketWithDetails = Ticket & {
  createdBy: UserWithoutPassword;
  assignedTo?: UserWithoutPassword;
  room?: Room;
  building?: Building;
  comments?: (TicketComment & { user: UserWithoutPassword })[];
};

export type RoomWithBuilding = Room & {
  building: Building;
};

export type UserWithRoomInfo = UserWithoutPassword & {
  room?: Room;
  building?: Building;
};
